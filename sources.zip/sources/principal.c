#include "data.h"
#include "interface.h"
#include "jeu.h"


int main()
{

    init_dessins_pieces(dessin_piece);
    printf("\n\n\n\n\n\n \t\tMETTRE EN PLEIN ECRAN PUIS APPUYER SUR UNE TOUCHE\n");getchar();


  return 0;
}
