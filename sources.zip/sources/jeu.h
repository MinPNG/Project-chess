
#include"data.h"

void init_jeu(echiquier);
void deplacer_piece(echiquier,deplacement d);

